export const API_URL = 'http://localhost:8080'
export const JPA_API_URL = 'http://localhost:8080/jpa'
